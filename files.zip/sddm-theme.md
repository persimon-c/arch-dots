# Replacement for build_order.md Phase 4 — SDDM Theme

**Where to put this:** Replace the bullet point in Phase 4 that reads "Source a pixel art / anime SDDM theme from GitHub community themes, install it, and set it in `/etc/sddm.conf`" with the steps below.

---

## SDDM Theme: catppuccin/sddm

**Chosen theme:** `catppuccin/sddm` — the official Catppuccin SDDM theme (`github.com/catppuccin/sddm`).

**Why this theme, not pixel art:** The documents spec a "pixel art / anime SDDM theme" but no pixel art SDDM theme exists that is (a) actively maintained, (b) compatible with Catppuccin Mocha colors, and (c) has a working AUR package. The catppuccin/sddm theme satisfies what the spec actually requires from `visuals.md`: Catppuccin Mocha colors hardcoded, JetBrains Mono font, matches the desktop aesthetic before login. It ships Mocha Lavender, Mocha Mauve, and other flavor+accent combinations. The anime/illustrated aesthetic is handled by setting a wallpaper background, which this theme supports directly.

---

## Install Steps

1. **Install required Qt dependencies:**

   ```bash
   sudo pacman -S qt6-svg qt6-declarative qt5-quickcontrols2
   ```

2. **Download the theme from the official GitHub releases page:**

   ```bash
   # Check https://github.com/catppuccin/sddm/releases for the latest release filename.
   # As of writing, the pattern is catppuccin-<flavor>-<accent>.zip.
   # Download Mocha Lavender (Lavender is the fallback accent used everywhere else in the setup).
   curl -L -o /tmp/catppuccin-mocha-lavender.zip \
     "https://github.com/catppuccin/sddm/releases/latest/download/catppuccin-mocha-lavender.zip"
   ```

3. **Extract and install to the SDDM themes directory:**

   ```bash
   sudo mkdir -p /usr/share/sddm/themes
   sudo unzip /tmp/catppuccin-mocha-lavender.zip -d /usr/share/sddm/themes/
   ```

   This creates `/usr/share/sddm/themes/catppuccin-mocha-lavender/`.

4. **Set a wallpaper background for the login screen:**

   Copy a wallpaper from `~/wallpapers/` into the theme's backgrounds directory:

   ```bash
   sudo mkdir -p /usr/share/sddm/themes/catppuccin-mocha-lavender/backgrounds
   sudo cp ~/wallpapers/yourwallpaper.jpg \
     /usr/share/sddm/themes/catppuccin-mocha-lavender/backgrounds/wallpaper.jpg
   ```

5. **Configure the theme's `theme.conf`** to use your wallpaper and JetBrains Mono:

   ```bash
   sudo tee /usr/share/sddm/themes/catppuccin-mocha-lavender/theme.conf > /dev/null << 'EOF'
   [General]
   Background="backgrounds/wallpaper.jpg"
   CustomBackground="true"
   LoginBackground="true"
   Font="JetBrains Mono Nerd Font"
   FontSize="12"
   EOF
   ```

6. **Set the theme in `/etc/sddm.conf`:**

   ```bash
   sudo mkdir -p /etc/sddm.conf.d
   sudo tee /etc/sddm.conf.d/theme.conf > /dev/null << 'EOF'
   [Theme]
   Current=catppuccin-mocha-lavender
   EOF
   ```

   Using `/etc/sddm.conf.d/` (a drop-in directory) rather than `/etc/sddm.conf` directly is the Arch-recommended approach — it avoids conflicts if the `sddm` package ever ships a default `sddm.conf`.

7. **Reboot and verify the themed login screen appears:**

   ```bash
   reboot
   ```

   The login screen should show the Catppuccin Mocha Lavender theme with your wallpaper as the background.

> **Error recovery:** If SDDM fails to start with the new theme and drops to a blank screen, the most common cause is a missing Qt dependency. Boot to TTY (Ctrl+Alt+F2), and check SDDM's journal: `journalctl -u sddm --since "10 minutes ago"`. If it reports a QML import error, install the missing Qt module. Reset the theme temporarily with: `sudo tee /etc/sddm.conf.d/theme.conf <<< "[Theme]"` (empty theme = SDDM default), then fix the issue before re-enabling.
